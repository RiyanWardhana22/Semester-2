public interface Convertible {
    double toCelsius();
    double toFahrenheit();
    double toKelvin();
    double toReaumur();
}

// Interface