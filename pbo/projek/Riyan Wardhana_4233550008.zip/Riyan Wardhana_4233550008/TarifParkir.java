public interface TarifParkir {
    float tarifMobil = 3000;
    float tarifMotor = 1000;

    float hitungBiaya();
}

// Interface